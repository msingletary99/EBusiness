package exceptions;

public class RecordNotFoundException extends Exception{
    public RecordNotFoundException(String msg) {
        super(msg);
    }
}
